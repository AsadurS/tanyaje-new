@extends('newtheme.layouts.main')
@section('styles')
<link rel="stylesheet" href="{{asset('new/css/popup.css') }}?lm=120920201428" />
<link href="{{asset('js/select2.min.css')}}" rel='stylesheet' type='text/css'>
<link href="{{asset('new/css/owl.carousel.min.css')}}" rel='stylesheet' type='text/css'>
<link href="{{asset('new/css/owl.theme.default.min.css')}}" rel='stylesheet' type='text/css'>
@endsection
@section('meta_for_share')
    <meta property="og:title" content="{{ trans('labels.website_title') }}">
    <meta property="og:url" content="https://tanyaje.com.my/">
    <meta property="og:image" content="{{asset('new/images/logo4.png')}}">
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="400" />
    <meta property="og:image:type" content="image/png">
    <meta property="og:description" content="Tanya-Je translated as “Just Ask” is the first most advanced online digital automotive classified in South East Asia.">
@endsection
@section('content')

    <!-- START content_part-->
    <section id="content_part">

        <section class="slider_section">
            <div class="container">
                <div class="owl-carousel owl-theme ">
                    @foreach($sliders as $slider)
                        <div class="item">
                            <a href="{!! $slider->sliders_url !!}" target="_blank">
                                <img src="/{!! $slider->path !!}">
                            </a>
                        </div>
                    @endforeach
                </>
            </div>
        </section>




    </section>
    <!-- END content_part-->
@endsection

@push("scripts")
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('js/select2.min.js')}}" type='text/javascript'></script>
    <script type="text/javascript" src="{!! asset('new/js/owl.carousel.min.js') !!}"></script>
    <script>

        jQuery(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            jQuery(".car_brand").on("change",function(){
                jQuery.post('/getModel',{make_id: $(this).val()},function(response){
                    response = JSON.parse(response);
                    html = '<option value="">Models</option>';
                    jQuery.each(response.data,function(i,val)
                    {
                        html += '<option value="'+val.model_id+'">'+val.model_name+'</option>"';
                    });
                    jQuery(".car_model").html(html);
                });
            });

            $('.owl-carousel').owlCarousel({
                loop:true,
                margin:10,
                nav:true,
                autoplay:true,
                autoplayTimeout:10000,
                autoplayHoverPause:true,
                responsive:{
                    0:{
                        items:1
                    }
                }
            })
            // Initialize select2
            var select2 = $(".merchant_name").select2();
            //select2.data('select2').$selection.css('height', '40px');

            var list = new cookieList("car_compare_list");
            var is_user = "{!! Auth::guard('customer')->check() !!}";
            jQuery(".compare_checkbox").on('click',function(){
                if(jQuery(this).prop('checked') == true) {
                    if(list.length() > 3)
                    {
                        alert("You can't campare more then 4 cars");
                        return false;
                    }
                    else
                    {
                        if(is_user)
                        {
                            jQuery.post("{!! route('carcompare.add') !!}",{car_id: $(this).val()},function(response){
                                alert(response);
                            });
                        }
                        else
                        {
                            list.add($(this).val());
                        }

                    }
                }
                else{
                        if(is_user)
                        {
                            jQuery.post("{!! route('carcompare.remove') !!}",{car_id: $(this).val()},function(response){
                                alert(response);
                            });
                        }
                        else
                        {
                            list.remove($(this).val());
                        }
                }
            });
        });

        var cookieList = function(cookieName) {
            var cookie = Cookies.get(cookieName);
            var items = cookie ? cookie.split(/,/) : new Array();
            return {
                "add": function(val) {
                    //Add to the items.
                    items.push(val);
                    Cookies.set(cookieName, items.join(','));
                },
                "remove": function (val) {
                    indx = items.indexOf(val);
                    if(indx!=-1) items.splice(indx, 1);
                    Cookies.set(cookieName, items.join(','));
                },
                "length": function () {
                    return items.length;
                    },
                "items": function() {
                    //Get all the items.
                    return items;
                }
            }
        }
    </script>

@endpush
